package com.product.Product.VO;

import com.product.Product.Entity.ProductEntity;
import lombok.*;

import java.io.Serializable;
@Data
@NoArgsConstructor
@Getter
@Setter
@AllArgsConstructor
public class ProductWithDescVO implements Serializable {
    private DescVO DescVo;
    private ProductEntity product;

    public DescVO getDescVo() {
        return DescVo;
    }

    public void setDescVo(DescVO descVo) {
        DescVo = descVo;
    }

    public ProductEntity getProduct() {
        return product;
    }

    public void setProduct(ProductEntity product) {
        this.product = product;
    }
}
