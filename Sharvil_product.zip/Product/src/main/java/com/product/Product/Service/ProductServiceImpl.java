package com.product.Product.Service;

import com.product.Product.DTO.ProductDTO;
import com.product.Product.Entity.ProductEntity;
import com.product.Product.VO.DescVO;
import com.product.Product.VO.ProductWithDescVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
@Service
public class ProductServiceImpl implements ProductService{
private ProductDTO productRepository;

@Autowired
ProductDescClient descClient;
    @Autowired
    public ProductServiceImpl(ProductDTO theProductRepsoitory){
        productRepository = theProductRepsoitory;
}
    @Override
    public ProductEntity findById(int id) {
        Optional<ProductEntity> res = productRepository.findById(id);
        ProductEntity s =  null;
        if(res.isPresent()){
            s = res.get();
        }
        else {
            throw new RuntimeException("Product By this Id Not found");
        }
        return s;
    }

    @Override
    public List<ProductEntity> findByType(String type) {
        List<ProductEntity> res = productRepository.findAll();
        ProductEntity s =  null;
        List<ProductEntity> filtered = new ArrayList<>();
        if(!res.isEmpty()){
            for (int i = 0; i < res.size(); i++) {
                s=res.get(i);
                if(type.equals(s.getType())){
                    filtered.add(s);
                }
            }
        }
        else {
            throw new RuntimeException("Procudt By this Type Not found");
        }
        return filtered;
    }

    @Override
    public ProductWithDescVO findDescById(int id) {
            Optional<ProductEntity> optional =productRepository.findById(id);
            if (optional.isPresent()) {
                ProductEntity productEntity = optional.get();
                Integer prId = productEntity.getId();
                DescVO descriptionVO = descClient.getDescById(prId);
                ProductWithDescVO pdVO = new ProductWithDescVO();
                pdVO.setProduct(productEntity);
                pdVO.setDescVo(descriptionVO);
                return pdVO;
            }
            return null;
        }


    @Override
    public ProductEntity addProduct(ProductEntity product) {
        return productRepository.save(product);
    }
}
