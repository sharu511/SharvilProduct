package com.product.Product.DTO;

import com.product.Product.Entity.ProductEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductDTO extends JpaRepository<ProductEntity,Integer> {
}
