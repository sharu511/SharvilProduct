package com.product.Product.Service;

import com.product.Product.VO.DescVO;
import com.product.Product.VO.ProductWithDescVO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "productDesc",url="http://localhost:8888")
public interface ProductDescClient {
    @GetMapping("desc/getdescById/{id}")
    public DescVO getDescById(@PathVariable int id);
}
