package com.productDescription.ProductDescription.Service;

import com.productDescription.ProductDescription.Entity.ProductDescEntity;

public interface ProductDescService {
    ProductDescEntity findById(int id);
    ProductDescEntity addProductDesc(ProductDescEntity product);
}
