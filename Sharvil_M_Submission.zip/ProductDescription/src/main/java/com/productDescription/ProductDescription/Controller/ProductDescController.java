package com.productDescription.ProductDescription.Controller;

import com.productDescription.ProductDescription.Entity.ProductDescEntity;
import com.productDescription.ProductDescription.Service.ProductDescService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RequestMapping("desc")
@RestController
public class ProductDescController {

    @Autowired
    private ProductDescService productDescService;

    @GetMapping("/getdescById/{id}")
    public ProductDescEntity getDescById(@PathVariable Integer id){
        return productDescService.findById(id);
    }
    @PostMapping("/add")
    public ProductDescEntity addProductDesc(@RequestBody ProductDescEntity productDesc ){
        return productDescService.addProductDesc(productDesc);
    }
}
