package com.productDescription.ProductDescription.DTO;

import com.productDescription.ProductDescription.Entity.ProductDescEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductDescDTO extends JpaRepository<ProductDescEntity,Integer> {
}
