package com.productDescription.ProductDescription.Service;

import com.productDescription.ProductDescription.DTO.ProductDescDTO;
import com.productDescription.ProductDescription.Entity.ProductDescEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;
@Service
public class ProductDescImpl implements ProductDescService{

    private ProductDescDTO productDescRepository;

    @Autowired
    public ProductDescImpl (ProductDescDTO theproductDescRepository){
        productDescRepository=theproductDescRepository;
    }
    @Override
    public ProductDescEntity findById(int id) {
        Optional<ProductDescEntity> res = productDescRepository.findById(id);
        ProductDescEntity s =  null;
        if(res.isPresent()){
            s = res.get();
        }
        else {
            throw new RuntimeException("Product By this Id Not found");
        }
        return s;
    }

    @Override
    public ProductDescEntity addProductDesc(ProductDescEntity product) {
        return productDescRepository.save(product);
    }
}
