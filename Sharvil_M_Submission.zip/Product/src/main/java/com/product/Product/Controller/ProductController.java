package com.product.Product.Controller;

import com.product.Product.Entity.ProductEntity;
import com.product.Product.Service.ProductService;
import com.product.Product.VO.ProductWithDescVO;
import jakarta.persistence.criteria.CriteriaBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("prod")
public class ProductController {
    @Autowired
    private ProductService productService;
    @GetMapping("/getById/{id}")
    public ProductEntity getById(@PathVariable Integer id){
        return productService.findById(id);
    }
    @GetMapping("/getByType/{type}")
    public List<ProductEntity> getById(@PathVariable String type){
        return productService.findByType(type);
    }

    @GetMapping("/getDescById/{id}")
    public ProductWithDescVO getByDescById(@PathVariable Integer id){
        return productService.findDescById(id);
    }
    @PostMapping("/add")
    public ProductEntity addProduct(@RequestBody ProductEntity product){
        return productService.addProduct(product);
    }
}
