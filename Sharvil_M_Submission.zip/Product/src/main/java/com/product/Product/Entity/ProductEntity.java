package com.product.Product.Entity;

import jakarta.persistence.*;
import lombok.Data;

@Table(name="product")
@Entity
public class ProductEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int Id;

    @Column(name="type")
    private String type;

    public int getId() {
        return Id;
    }

    public void setId(int id) {
        Id = id;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public ProductEntity() {
    }

    public ProductEntity(int id, String type) {
        Id = id;
        this.type = type;
    }
}
