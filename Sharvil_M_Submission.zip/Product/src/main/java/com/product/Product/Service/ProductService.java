package com.product.Product.Service;

import com.product.Product.Entity.ProductEntity;
import com.product.Product.VO.ProductWithDescVO;

import java.util.List;

public interface ProductService {

    ProductEntity findById(int id);

    List<ProductEntity> findByType(String type);

    ProductWithDescVO findDescById(int id);

    ProductEntity addProduct(ProductEntity product);
}
